import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import ProductStats from './views/ProductStats';
import ProductEditor from './views/ProductEditor';
import ProductsList from './views/ProductsList';
import './index.css';
import productActionCreators from './actions';

class Products extends Component {
    render() {
        console.log('inside product component',this.props);
       // const categoryData = this.props.categories;
        //const productData = this.props.products;
        //const {products, categories} = this.props;
        const { data, toggleOutOfStock, remove, removeOutOfStock, addNew} = this.props;
        console.log('inside product component data values is',data);
        return (
            <div>
                <h3>Products</h3>
                <hr />
                <ProductStats products={data.products} />
                <ProductEditor addNew={addNew} categoriesList={data.categories}  />
                <ProductsList
                    products={data.products}
                    toggleOutOfStock={toggleOutOfStock}
                    remove={remove}
                    removeOutOfStock={removeOutOfStock}
                />
            </div>
        )
    }
}

function mapStateToProps(storeState){
    //const products = storeState.products;
   // const categories = storeState.categories;
   // const finalData = {products,categories};
    //return { data : storeState};
    const products = storeState.products;
    return { data : storeState };
   // return { data : storeState,categoriesData:storeState.categories};
}

function mapDispatchToProps(dispatch){
    const productActionDispatchers = bindActionCreators(productActionCreators, dispatch);
    return productActionDispatchers;
}

export default connect(mapStateToProps, mapDispatchToProps)(Products);