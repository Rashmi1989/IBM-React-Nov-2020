import React, { Component } from 'react';

class ProductEditor extends Component {
    state = {
        name: '',
        description: '',
        price: 0,
        categoryName:''
    };

    onAddNewProductClick = () => {
        const { addNew,categoriesList } = this.props,
            { name, description, price, categoryName } = this.state;
        console.log('inside prod editorjs',this.state); 
        addNew(name, description, price,categoryName);
    };
    onChangeDropdown = (evt) =>{
       console.log('onchangedropdown evt',evt.target.value);
    };
    render() {

        //const optionList = categoriesList.map(catogory=>(id,categoryName))

        const optionList = this.props.categoriesList.map((categoryName, index) => (<option key={index}>{categoryName.name}</option>));
        return (
          <section className="edit">
            <div className="field">
              <label htmlFor="">Name :</label>
              <input
                type="text"
                onChange={evt => this.setState({ name: evt.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="">Description :</label>
              <input
                type="text"
                onChange={evt =>
                  this.setState({ description: evt.target.value })
                }
              />
            </div>
            <div className="field">
              <label htmlFor="">Price :</label>
              <input
                type="number"
                onChange={evt =>
                  this.setState({ price: parseInt(evt.target.value) })
                }
              />
            </div>
            <div className="field">
              <label htmlFor="">Category</label>
              <select onChange={evt =>{this.setState({categoryName:evt.target.value})}}>
                {optionList}
              </select>
            </div>
            <div className="field">
              <input
                type="button"
                value="Add Product"
                onClick={this.onAddNewProductClick}
              />
            </div>
          </section>
        );
    }
}

export default ProductEditor;