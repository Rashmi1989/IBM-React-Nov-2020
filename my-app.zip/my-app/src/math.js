export function add(x,y){
    return x + y;
}

export function subtract(x,y){
    return x - y;
}

//default export
export default { add, subtract };